#include "robot_driver/hardware_interfaces/ylo2_interface.h"

Ylo2Interface::Ylo2Interface() {}

void Ylo2Interface::loadInterface(int argc, char** argv) {}

void Ylo2Interface::unloadInterface() {}

bool Ylo2Interface::send(
    const quad_msgs::LegCommandArray& last_leg_command_array_msg,
    const Eigen::VectorXd& user_tx_data) 
    {
        return true;
    }

bool Ylo2Interface::recv(sensor_msgs::JointState& joint_state_msg,
                           sensor_msgs::Imu& imu_msg,
                           Eigen::VectorXd& user_rx_data) 
    {
        // Get the data and appropriate timestamp (this may be blocking)

    // Transform from rpy to quaternion
    geometry_msgs::Quaternion orientation_msg;
    tf2::Quaternion quat_tf;
    Eigen::Vector3f rpy;
    /*
    quat_tf.setRPY(mbdata["imu_euler"][0], mbdata["imu_euler"][1],
                 mbdata["imu_euler"][2]);
    tf2::convert(quat_tf, orientation_msg);

    // Load the data into the imu message
    imu_msg.orientation = orientation_msg;
    imu_msg.angular_velocity.x = mbdata["imu_angular_velocity"][0];
    imu_msg.angular_velocity.y = mbdata["imu_angular_velocity"][1];
    imu_msg.angular_velocity.z = mbdata["imu_angular_velocity"][2];

    // I guess the acceleration is opposite
    imu_msg.linear_acceleration.x = -mbdata["imu_linear_acceleration"][0];
    imu_msg.linear_acceleration.y = -mbdata["imu_linear_acceleration"][1];
    imu_msg.linear_acceleration.z = -mbdata["imu_linear_acceleration"][2];
    */

    return true;
    }